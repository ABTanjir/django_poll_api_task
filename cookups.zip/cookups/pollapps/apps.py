from django.apps import AppConfig


class PollappsConfig(AppConfig):
    name = 'pollapps'
